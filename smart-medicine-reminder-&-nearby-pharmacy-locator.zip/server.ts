import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import nodemailer from "nodemailer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// In-memory OTP store (for demo purposes)
const otpStore: { [email: string]: { otp: string; expires: number } } = {};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // OTP Send Route
  app.post("/api/auth/send-otp", async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: "Invalid email format" });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    otpStore[email] = { otp, expires: Date.now() + 5 * 60 * 1000 }; // 5 mins

    console.log(`[AUTH] Generated OTP for ${email}: ${otp}`);

    const smtpConfigured = !!(process.env.SMTP_USER && process.env.SMTP_PASS);

    if (smtpConfigured) {
      try {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST || "smtp.gmail.com",
          port: parseInt(process.env.SMTP_PORT || "587"),
          secure: process.env.SMTP_SECURE === "true",
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
          timeout: 10000, // 10 seconds timeout
        });

        await transporter.sendMail({
          from: `"MedSmart Support" <${process.env.SMTP_USER}>`,
          to: email,
          subject: "Your MedSmart Verification Code",
          text: `Hello,\n\nYour verification code for MedSmart is: ${otp}\n\nThis code will expire in 5 minutes.\n\nIf you did not request this code, please ignore this email.`,
          html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e5e7eb; rounded: 12px;">
              <h2 style="color: #2563eb; margin-bottom: 20px;">MedSmart Verification</h2>
              <p style="color: #4b5563; font-size: 16px;">Hello,</p>
              <p style="color: #4b5563; font-size: 16px;">Use the following code to complete your login to MedSmart:</p>
              <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; text-align: center; margin: 24px 0;">
                <span style="font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #111827;">${otp}</span>
              </div>
              <p style="color: #6b7280; font-size: 14px;">This code will expire in 5 minutes.</p>
              <hr style="border: 0; border-top: 1px solid #e5e7eb; margin: 24px 0;" />
              <p style="color: #9ca3af; font-size: 12px;">If you did not request this code, please ignore this email.</p>
            </div>
          `,
        });
        return res.json({ success: true, message: "OTP sent successfully to your email.", smtpConfigured: true });
      } catch (error: any) {
        console.error("[AUTH] Failed to send email:", error);
        // Fallback if email sending fails even if configured
        return res.status(500).json({ 
          error: "Failed to deliver email. Please try again later.", 
          details: process.env.NODE_ENV === 'development' ? error.message : undefined,
          smtpConfigured: true 
        });
      }
    }

    // Fallback message when SMTP is not configured
    res.json({ 
      success: true, 
      message: "Development Mode: OTP generated successfully. Since email service is not configured, please check the server logs for your code.",
      smtpConfigured: false,
      otp: process.env.NODE_ENV === 'development' ? otp : undefined // Only expose in dev
    });
  });

  // OTP Verify Route
  app.post("/api/auth/verify-otp", (req, res) => {
    const { email, otp } = req.body;
    if (!email || !otp) return res.status(400).json({ error: "Email and OTP are required" });

    const stored = otpStore[email];
    if (!stored || stored.otp !== otp || stored.expires < Date.now()) {
      return res.status(400).json({ error: "Invalid or expired OTP" });
    }

    delete otpStore[email]; // Clear OTP after use
    res.json({ message: "OTP verified successfully", user: { email, uid: `user-${email.replace(/[@.]/g, '-')}` } });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
