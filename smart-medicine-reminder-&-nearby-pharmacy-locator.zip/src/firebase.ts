import { GoogleGenAI } from "@google/genai";

// Mocking Firebase for LocalStorage use
const mockAuth = {
  currentUser: JSON.parse(localStorage.getItem("medsmart_user") || "null"),
  onAuthStateChanged: (callback: (user: any) => void) => {
    const user = JSON.parse(localStorage.getItem("medsmart_user") || "null");
    callback(user);
    return () => {};
  }
};

export const auth = mockAuth as any;
export const googleProvider = {};

export const signInWithPopup = async (auth: any, provider: any) => {
  const mockUser = {
    uid: "mock-user-123",
    email: "user@example.com",
    displayName: "Demo User",
    photoURL: "https://api.dicebear.com/7.x/avataaars/svg?seed=Demo",
    providerData: []
  };
  localStorage.setItem("medsmart_user", JSON.stringify(mockUser));
  window.location.reload();
  return { user: mockUser };
};

export const signInWithEmailOTP = async (email: string) => {
  const response = await fetch("/api/auth/send-otp", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to send OTP");
  }
  return response.json();
};

export const verifyOTP = async (email: string, otp: string) => {
  const response = await fetch("/api/auth/verify-otp", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, otp }),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Invalid OTP");
  }
  const { user } = await response.json();
  const userData = {
    ...user,
    displayName: user.email.split("@")[0],
    photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`,
    providerData: []
  };
  localStorage.setItem("medsmart_user", JSON.stringify(userData));
  window.location.reload();
  return { user: userData };
};

export const signOut = async (auth: any) => {
  localStorage.removeItem("medsmart_user");
  window.location.reload();
};

// Mock Firestore using LocalStorage
const getStorage = (key: string) => JSON.parse(localStorage.getItem(`medsmart_${key}`) || "[]");
const setStorage = (key: string, data: any) => localStorage.setItem(`medsmart_${key}`, JSON.stringify(data));

export const db = {} as any;

export const collection = (db: any, path: string) => path;
export const doc = (db: any, path: string, id?: string) => ({ path, id });

export const setDoc = async (docRef: any, data: any) => {
  const items = getStorage(docRef.path);
  const index = items.findIndex((item: any) => item.id === docRef.id);
  const newItem = { ...data, id: docRef.id };
  if (index > -1) items[index] = newItem;
  else items.push(newItem);
  setStorage(docRef.path, items);
  window.dispatchEvent(new Event('storage_update'));
};

export const addDoc = async (path: string, data: any) => {
  const items = getStorage(path);
  const newItem = { ...data, id: Math.random().toString(36).substr(2, 9) };
  items.push(newItem);
  setStorage(path, items);
  window.dispatchEvent(new Event('storage_update'));
  return { id: newItem.id };
};

export const getDoc = async (docRef: any) => {
  const items = getStorage(docRef.path);
  const item = items.find((i: any) => i.id === docRef.id);
  return { exists: () => !!item, data: () => item };
};

export const updateDoc = async (docRef: any, data: any) => {
  const items = getStorage(docRef.path);
  const index = items.findIndex((item: any) => item.id === docRef.id);
  if (index > -1) {
    items[index] = { ...items[index], ...data };
    setStorage(docRef.path, items);
    window.dispatchEvent(new Event('storage_update'));
  }
};

export const deleteDoc = async (docRef: any) => {
  const items = getStorage(docRef.path);
  const filtered = items.filter((i: any) => i.id !== docRef.id);
  setStorage(docRef.path, filtered);
  window.dispatchEvent(new Event('storage_update'));
};

export const query = (path: string, ...constraints: any[]) => ({ path, constraints });
export const where = (field: string, op: string, value: any) => ({ field, op, value });

export const onSnapshot = (q: any, callback: (snapshot: any) => void) => {
  const handler = () => {
    let items = getStorage(q.path || q);
    // Simple mock filtering for 'uid' and 'scheduledTime'
    if (q.constraints) {
      q.constraints.forEach((c: any) => {
        if (c.op === "==") items = items.filter((i: any) => i[c.field] === c.value);
        if (c.op === ">=") items = items.filter((i: any) => i[c.field] >= c.value);
        if (c.op === "<=") items = items.filter((i: any) => i[c.field] <= c.value);
      });
    }
    callback({
      docs: items.map((item: any) => ({
        id: item.id,
        data: () => item
      }))
    });
  };
  window.addEventListener('storage_update', handler);
  handler();
  return () => window.removeEventListener('storage_update', handler);
};

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  console.error('Mock Storage Error: ', error, operationType, path);
}
