import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getMedicineInfo(medicineName: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Provide information about the medicine: ${medicineName}. Include usage, common side effects, and precautions.`,
    config: {
      systemInstruction: "You are a helpful medical information assistant. Provide concise and accurate information about medicines.",
    },
  });
  return response.text;
}

export async function askHealthQuestion(question: string, imageData?: string) {
  const parts: any[] = [{ text: question }];
  
  if (imageData) {
    parts.push({
      inlineData: {
        data: imageData.split(",")[1], // Remove the data:image/png;base64, prefix
        mimeType: "image/png",
      },
    });
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: { parts },
    config: {
      systemInstruction: `You are a highly advanced, empathetic, and professional health assistant. 
      Your goal is to help users understand their health concerns through a conversational and diagnostic-oriented approach.
      
      Guidelines:
      1. **Interactive Diagnosis**: Instead of just giving an answer, ask clarifying questions. For example: "What symptoms have you seen?", "How long have you had this?", "Is there any pain?".
      2. **Medicine Information**: When asked about medicines, provide information on common and effective options for the described symptoms. Clearly state standard treatments but ALWAYS include a strong medical disclaimer.
      3. **Image Analysis**: If the user provides an image (e.g., a rash, a medicine bottle, or a symptom), analyze it carefully and provide relevant information.
      4. **Medical Disclaimer**: ALWAYS advise the user to consult a qualified doctor or healthcare professional before taking any medication or making health decisions.
      5. **Specialist Recommendation**: Suggest specific types of doctors to consult (e.g., "You should consult a General Physician, a Dermatologist, or an ENT specialist").
      6. **Tone**: Keep responses concise, empathetic, and professional. Use a supportive tone.
      7. **Safety**: If symptoms sound emergency-like (e.g., chest pain, severe bleeding), advise immediate emergency care.`,
    },
  });
  return response.text;
}

export async function getNearbyPharmacies(lat: number, lng: number) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Find 5 nearby pharmacies near latitude ${lat} and longitude ${lng}. Return the results as a JSON array of objects with 'name', 'address', and 'distance' fields.`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: {
        retrievalConfig: {
          latLng: {
            latitude: lat,
            longitude: lng
          }
        }
      },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            address: { type: Type.STRING },
            distance: { type: Type.STRING }
          },
          required: ["name", "address"]
        }
      }
    },
  });
  return JSON.parse(response.text);
}
