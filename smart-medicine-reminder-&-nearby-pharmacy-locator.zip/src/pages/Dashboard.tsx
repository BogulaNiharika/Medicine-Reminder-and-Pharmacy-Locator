import React, { useEffect, useState } from "react";
import { auth, db, collection, query, where, onSnapshot, doc, updateDoc, setDoc } from "../firebase";
import { format, isSameDay, parseISO, startOfDay, endOfDay } from "date-fns";
import { Pill, AlertCircle, CheckCircle2, Clock, Plus, ChevronRight, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { toast } from "sonner";
import { cn } from "../lib/utils";

interface Medicine {
  id: string;
  name: string;
  dosage: string;
  stock: number;
  stockAlertThreshold: number;
  times: string[];
}

interface DoseLog {
  id: string;
  medicineId: string;
  medicineName: string;
  scheduledTime: string;
  status: "taken" | "missed";
}

export default function Dashboard() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [todayLogs, setTodayLogs] = useState<DoseLog[]>([]);
  const [loading, setLoading] = useState(true);

  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;

    // Fetch medicines
    const qMeds = query(collection(db, "medicines"), where("uid", "==", user.uid));
    const unsubMeds = onSnapshot(qMeds, (snapshot) => {
      const meds = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Medicine));
      setMedicines(meds);
      setLoading(false);
    });

    // Fetch today's logs
    const todayStart = startOfDay(new Date()).toISOString();
    const todayEnd = endOfDay(new Date()).toISOString();
    const qLogs = query(
      collection(db, "doseLogs"),
      where("uid", "==", user.uid),
      where("scheduledTime", ">=", todayStart),
      where("scheduledTime", "<=", todayEnd)
    );
    const unsubLogs = onSnapshot(qLogs, (snapshot) => {
      const logs = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as DoseLog));
      setTodayLogs(logs);
    });

    return () => {
      unsubMeds();
      unsubLogs();
    };
  }, [user]);

  const handleTakeDose = async (medicine: Medicine, time: string) => {
    try {
      const scheduledTime = format(new Date(), "yyyy-MM-dd") + "T" + time + ":00";
      const logId = `${medicine.id}_${time}_${format(new Date(), "yyyyMMdd")}`;
      
      await setDoc(doc(db, "doseLogs", logId), {
        uid: user?.uid,
        medicineId: medicine.id,
        medicineName: medicine.name,
        scheduledTime,
        takenAt: new Date().toISOString(),
        status: "taken",
      });

      // Update stock
      if (medicine.stock > 0) {
        await updateDoc(doc(db, "medicines", medicine.id), {
          stock: medicine.stock - 1,
        });
      }

      toast.success(`Dose of ${medicine.name} recorded!`);
    } catch (error) {
      console.error("Error taking dose:", error);
      toast.error("Failed to record dose.");
    }
  };

  const statsData = [
    { name: "Taken", value: todayLogs.filter(l => l.status === "taken").length },
    { name: "Missed", value: todayLogs.filter(l => l.status === "missed").length },
    { name: "Remaining", value: medicines.reduce((acc, m) => acc + m.times.length, 0) - todayLogs.length }
  ].filter(d => d.value > 0);

  const COLORS = ["#2563eb", "#ef4444", "#e5e7eb"];

  const lowStockMeds = medicines.filter(m => m.stock <= (m.stockAlertThreshold || 5));

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">
            Hello, {user?.displayName?.split(" ")[0]}!
          </h1>
          <p className="text-neutral-500 mt-1 font-medium">
            {format(new Date(), "EEEE, MMMM do")}
          </p>
        </div>
        <Link
          to="/medicines"
          className="flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
        >
          <Plus size={20} />
          Add Medicine
        </Link>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Today's Schedule */}
        <div className="lg:col-span-2 space-y-6">
          <section className="bg-white rounded-3xl p-8 border border-neutral-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-neutral-900 flex items-center gap-2">
                <Clock className="text-blue-600" size={24} />
                Today's Schedule
              </h2>
              <span className="text-sm font-semibold text-neutral-400 bg-neutral-50 px-3 py-1 rounded-full">
                {todayLogs.filter(l => l.status === "taken").length} / {medicines.reduce((acc, m) => acc + m.times.length, 0)} Taken
              </span>
            </div>

            {medicines.length === 0 ? (
              <div className="text-center py-12 border-2 border-dashed border-neutral-100 rounded-2xl">
                <Pill className="mx-auto text-neutral-200 mb-4" size={48} />
                <p className="text-neutral-400 font-medium">No medicines scheduled yet.</p>
                <Link to="/medicines" className="text-blue-600 font-semibold mt-2 inline-block">Add your first medicine</Link>
              </div>
            ) : (
              <div className="space-y-4">
                {medicines.flatMap(med => med.times.map(time => ({ med, time }))).sort((a, b) => a.time.localeCompare(b.time)).map(({ med, time }, idx) => {
                  const log = todayLogs.find(l => l.medicineId === med.id && l.scheduledTime.includes(time));
                  const isTaken = log?.status === "taken";
                  
                  return (
                    <div key={`${med.id}-${time}-${idx}`} className={cn(
                      "flex items-center justify-between p-4 rounded-2xl border transition-all",
                      isTaken ? "bg-neutral-50 border-neutral-100 opacity-60" : "bg-white border-neutral-100 hover:border-blue-200 hover:shadow-md"
                    )}>
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm",
                          isTaken ? "bg-neutral-200 text-neutral-500" : "bg-blue-100 text-blue-600"
                        )}>
                          {time}
                        </div>
                        <div>
                          <h3 className="font-bold text-neutral-900">{med.name}</h3>
                          <p className="text-xs text-neutral-500 font-medium">{med.dosage}</p>
                        </div>
                      </div>
                      
                      {isTaken ? (
                        <div className="flex items-center gap-2 text-green-600 font-bold text-sm">
                          <CheckCircle2 size={20} />
                          Taken
                        </div>
                      ) : (
                        <button
                          onClick={() => handleTakeDose(med, time)}
                          className="bg-blue-600 text-white px-5 py-2 rounded-xl font-bold text-sm hover:bg-blue-700 transition-colors"
                        >
                          Take Now
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Stock Alerts */}
          {lowStockMeds.length > 0 && (
            <section className="bg-red-50 rounded-3xl p-8 border border-red-100">
              <h2 className="text-xl font-bold text-red-900 flex items-center gap-2 mb-6">
                <AlertCircle size={24} />
                Low Stock Alerts
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {lowStockMeds.map(med => (
                  <div key={med.id} className="bg-white p-4 rounded-2xl border border-red-100 flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-neutral-900">{med.name}</h3>
                      <p className="text-sm text-red-600 font-bold">{med.stock} doses left</p>
                    </div>
                    <Link to="/pharmacies" className="text-blue-600 p-2 hover:bg-blue-50 rounded-lg transition-colors">
                      <ChevronRight size={20} />
                    </Link>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Sidebar Stats */}
        <div className="space-y-8">
          <section className="bg-white rounded-3xl p-8 border border-neutral-100 shadow-sm">
            <h2 className="text-xl font-bold text-neutral-900 flex items-center gap-2 mb-6">
              <TrendingUp className="text-blue-600" size={24} />
              Daily Progress
            </h2>
            <div className="h-64">
              {statsData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statsData}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {statsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36}/>
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-neutral-300 italic text-sm">
                  No data for today
                </div>
              )}
            </div>
          </section>

          <section className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-8 text-white shadow-xl shadow-blue-200">
            <h2 className="text-xl font-bold mb-4">Emergency Contact</h2>
            <p className="text-blue-100 text-sm mb-6 leading-relaxed">
              We'll notify your emergency contact if you miss 3 consecutive doses.
            </p>
            <Link to="/profile" className="inline-block w-full text-center bg-white/20 hover:bg-white/30 backdrop-blur-md text-white font-bold py-3 rounded-2xl transition-all border border-white/20">
              Manage Contacts
            </Link>
          </section>
        </div>
      </div>
    </div>
  );
}
