import React, { useEffect, useState } from "react";
import { MapPin, Navigation, Phone, Search, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { getNearbyPharmacies } from "../services/geminiService";

interface Pharmacy {
  name: string;
  address: string;
  distance: string;
  phone?: string;
  rating?: number;
}

export default function Pharmacies() {
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);

  const findPharmacies = async () => {
    setLoading(true);
    try {
      if (!navigator.geolocation) {
        toast.error("Geolocation is not supported by your browser.");
        setLoading(false);
        return;
      }

      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        setLocation({ lat: latitude, lng: longitude });
        
        try {
          const results = await getNearbyPharmacies(latitude, longitude);
          setPharmacies(results);
          toast.success("Nearby pharmacies found!");
        } catch (error) {
          console.error("Error fetching pharmacies:", error);
          toast.error("Failed to find pharmacies. Please try again.");
        } finally {
          setLoading(false);
        }
      }, (error) => {
        console.error("Geolocation Error:", error);
        toast.error("Please enable location access to find nearby pharmacies.");
        setLoading(false);
      });
    } catch (error) {
      console.error("Error in findPharmacies:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    findPharmacies();
  }, []);

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Nearby Pharmacies</h1>
          <p className="text-neutral-500 mt-1 font-medium">Find the nearest pharmacy when your stock is low.</p>
        </div>
        <button
          onClick={findPharmacies}
          disabled={loading}
          className="flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : <Navigation size={20} />}
          Refresh Location
        </button>
      </header>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 animate-pulse">
            <MapPin size={32} />
          </div>
          <p className="text-neutral-500 font-medium animate-pulse">Searching for pharmacies nearby...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pharmacies.length > 0 ? (
            pharmacies.map((pharmacy, idx) => (
              <div key={idx} className="bg-white rounded-3xl p-6 border border-neutral-100 shadow-sm hover:shadow-md transition-all group">
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                  <MapPin size={24} />
                </div>
                
                <h3 className="text-xl font-bold text-neutral-900 mb-2">{pharmacy.name}</h3>
                <p className="text-neutral-500 text-sm mb-4 leading-relaxed font-medium">
                  {pharmacy.address}
                </p>
                
                <div className="flex flex-col gap-2 mb-6">
                  <div className="flex items-center gap-2 text-blue-600 font-bold text-sm">
                    <Navigation size={16} />
                    {pharmacy.distance || "Nearby"}
                  </div>
                  {location && (
                    <div className="text-[10px] text-neutral-400 font-mono">
                      Your Location: {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                    </div>
                  )}
                </div>

                <div className="pt-6 border-t border-neutral-50 flex flex-col gap-3">
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(pharmacy.name + " " + pharmacy.address)}&travelmode=driving`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-blue-600 text-white text-center py-3 rounded-xl font-bold text-sm hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-100"
                  >
                    <ExternalLink size={16} />
                    Connect & Navigate
                  </a>
                  <div className="flex gap-2">
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(pharmacy.name + " " + pharmacy.address)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-neutral-100 text-neutral-700 text-center py-3 rounded-xl font-bold text-xs hover:bg-neutral-200 transition-all flex items-center justify-center gap-2"
                    >
                      <MapPin size={14} />
                      View on Map
                    </a>
                    {pharmacy.phone && (
                      <a
                        href={`tel:${pharmacy.phone}`}
                        className="p-3 bg-neutral-100 text-neutral-600 rounded-xl hover:bg-neutral-200 transition-all"
                      >
                        <Phone size={20} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-24 border-2 border-dashed border-neutral-100 rounded-3xl">
              <Search className="mx-auto text-neutral-200 mb-4" size={48} />
              <p className="text-neutral-400 font-medium">No pharmacies found in your area.</p>
              <button onClick={findPharmacies} className="text-blue-600 font-bold mt-2 hover:underline">Try again</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
