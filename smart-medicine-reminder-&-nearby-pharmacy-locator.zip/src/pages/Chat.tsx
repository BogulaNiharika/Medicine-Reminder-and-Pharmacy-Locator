import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, Bot, User, Loader2, Info, Camera, X, Check } from "lucide-react";
import { askHealthQuestion } from "../services/geminiService";
import { cn } from "../lib/utils";
import { toast } from "sonner";

interface Message {
  role: "user" | "bot";
  text: string;
  timestamp: Date;
  image?: string;
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "bot",
      text: "Hello! I'm your MedSmart health assistant. How can I help you today? You can ask me about medicine usage, health tips, or general wellness.",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setShowCamera(true);
      }
    } catch (err) {
      console.error("Camera Error:", err);
      toast.error("Could not access camera.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setShowCamera(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext("2d");
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL("image/png");
        setCapturedImage(dataUrl);
        stopCamera();
      }
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !capturedImage) || loading) return;

    const userMessage: Message = {
      role: "user",
      text: input || (capturedImage ? "Analyzed this image." : ""),
      timestamp: new Date(),
      image: capturedImage || undefined,
    };

    setMessages((prev) => [...prev, userMessage]);
    const currentInput = input;
    const currentImage = capturedImage;
    setInput("");
    setCapturedImage(null);
    setLoading(true);

    try {
      const response = await askHealthQuestion(currentInput || "What can you tell me about this image?", currentImage || undefined);
      const botMessage: Message = {
        role: "bot",
        text: response,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Chat Error:", error);
      toast.error("Failed to get response from AI.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-12rem)] flex flex-col bg-white rounded-3xl border border-neutral-100 shadow-sm overflow-hidden relative">
      {showCamera && (
        <div className="absolute inset-0 z-50 bg-black flex flex-col items-center justify-center">
          <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
          <div className="absolute bottom-10 flex gap-6">
            <button onClick={stopCamera} className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white">
              <X size={32} />
            </button>
            <button onClick={capturePhoto} className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-blue-600 shadow-xl">
              <Camera size={40} />
            </button>
          </div>
        </div>
      )}
      <canvas ref={canvasRef} className="hidden" />

      <header className="p-6 border-b border-neutral-100 flex items-center justify-between bg-white sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white">
            <Bot size={24} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-neutral-900">Health Assistant</h2>
            <div className="flex items-center gap-1.5 text-xs text-green-500 font-bold">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Online
            </div>
          </div>
        </div>
        <div className="p-2 text-neutral-400 hover:text-neutral-600 cursor-help group relative">
          <Info size={20} />
          <div className="absolute right-0 top-full mt-2 w-48 p-3 bg-neutral-900 text-white text-[10px] rounded-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
            AI responses are for information only. Consult a doctor for medical advice.
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={cn(
              "flex items-start gap-3 max-w-[85%]",
              msg.role === "user" ? "ml-auto flex-row-reverse" : ""
            )}
          >
            <div
              className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                msg.role === "user" ? "bg-blue-100 text-blue-600" : "bg-neutral-100 text-neutral-600"
              )}
            >
              {msg.role === "user" ? <User size={18} /> : <Bot size={18} />}
            </div>
            <div
              className={cn(
                "p-4 rounded-2xl text-sm leading-relaxed",
                msg.role === "user"
                  ? "bg-blue-600 text-white font-medium rounded-tr-none"
                  : "bg-neutral-50 text-neutral-800 rounded-tl-none border border-neutral-100"
              )}
            >
              {msg.image && (
                <img src={msg.image} alt="Captured" className="w-full max-w-xs rounded-xl mb-3 border border-white/20" />
              )}
              <p className="whitespace-pre-wrap">{msg.text}</p>
              <span className={cn(
                "text-[10px] mt-2 block opacity-50",
                msg.role === "user" ? "text-blue-100" : "text-neutral-400"
              )}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-start gap-3 max-w-[85%] animate-in fade-in duration-300">
            <div className="w-8 h-8 bg-neutral-100 text-neutral-600 rounded-lg flex items-center justify-center">
              <Bot size={18} />
            </div>
            <div className="bg-neutral-50 p-4 rounded-2xl rounded-tl-none border border-neutral-100">
              <Loader2 className="animate-spin text-blue-600" size={18} />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <footer className="p-6 border-t border-neutral-100 bg-white">
        {capturedImage && (
          <div className="mb-4 relative inline-block">
            <img src={capturedImage} alt="Preview" className="w-20 h-20 object-cover rounded-xl border-2 border-blue-500" />
            <button onClick={() => setCapturedImage(null)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg">
              <X size={12} />
            </button>
          </div>
        )}
        <form onSubmit={handleSend} className="flex items-center gap-3">
          <button
            type="button"
            onClick={startCamera}
            className="w-14 h-14 bg-neutral-100 text-neutral-600 rounded-2xl flex items-center justify-center hover:bg-neutral-200 transition-all shrink-0"
          >
            <Camera size={24} />
          </button>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a health question..."
            className="flex-1 px-5 py-4 rounded-2xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all text-sm font-medium"
          />
          <button
            type="submit"
            disabled={(!input.trim() && !capturedImage) || loading}
            className="w-14 h-14 bg-blue-600 text-white rounded-2xl flex items-center justify-center hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
          >
            <Send size={24} />
          </button>
        </form>
      </footer>
    </div>
  );
}
