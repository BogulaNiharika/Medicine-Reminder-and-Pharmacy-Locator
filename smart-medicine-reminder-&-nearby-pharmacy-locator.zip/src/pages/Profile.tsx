import React, { useEffect, useState } from "react";
import { auth, db, doc, getDoc, updateDoc } from "../firebase";
import { User, Phone, ShieldAlert, Save, Loader2, Mail, Bell } from "lucide-react";
import { toast } from "sonner";

interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  phone: string;
  emergencyContactPhone: string;
  emergencyContactName: string;
}

export default function Profile() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;

    const fetchProfile = async () => {
      try {
        const docRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setProfile(docSnap.data() as UserProfile);
        }
      } catch (error) {
        console.error("Error fetching profile:", error);
        toast.error("Failed to load profile.");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    setSaving(true);
    try {
      const docRef = doc(db, "users", user.uid);
      await updateDoc(docRef, {
        displayName: profile.displayName,
        phone: profile.phone,
        emergencyContactPhone: profile.emergencyContactPhone,
        emergencyContactName: profile.emergencyContactName,
      });
      toast.success("Profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error("Failed to update profile.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <Loader2 className="animate-spin text-blue-600" size={32} />
        <p className="text-neutral-500 font-medium">Loading your profile...</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">My Profile</h1>
        <p className="text-neutral-500 mt-1 font-medium">Manage your personal information and emergency settings.</p>
      </header>

      <div className="bg-white rounded-3xl p-8 border border-neutral-100 shadow-sm space-y-10">
        {/* Basic Info */}
        <section className="space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-neutral-50">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
              <User size={20} />
            </div>
            <h2 className="text-xl font-bold text-neutral-900">Personal Information</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Full Name</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
                <input
                  type="text"
                  value={profile?.displayName || ""}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, displayName: e.target.value } : null)}
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-medium"
                  placeholder="Your Full Name"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Email Address</label>
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-neutral-50 border border-neutral-100 text-neutral-500 font-medium overflow-hidden">
                <Mail size={18} />
                <span className="truncate">{profile?.email}</span>
              </div>
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-bold text-neutral-700">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
                <input
                  type="tel"
                  value={profile?.phone || ""}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, phone: e.target.value } : null)}
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-medium"
                  placeholder="+1 (555) 000-0000"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Emergency Contact */}
        <section className="space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-neutral-50">
            <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center text-red-600">
              <ShieldAlert size={20} />
            </div>
            <h2 className="text-xl font-bold text-neutral-900">Emergency Contact</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Contact Name</label>
              <input
                type="text"
                value={profile?.emergencyContactName || ""}
                onChange={(e) => setProfile(prev => prev ? { ...prev, emergencyContactName: e.target.value } : null)}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-medium"
                placeholder="e.g. John Doe (Spouse)"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Contact Phone</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
                <input
                  type="tel"
                  value={profile?.emergencyContactPhone || ""}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, emergencyContactPhone: e.target.value } : null)}
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all font-medium"
                  placeholder="+1 (555) 000-0000"
                />
              </div>
            </div>
          </div>
          <div className="p-4 bg-red-50 rounded-2xl flex gap-3 border border-red-100">
            <Bell className="text-red-600 shrink-0" size={20} />
            <p className="text-xs text-red-800 leading-relaxed font-medium">
              Important: This contact will be notified via SMS if you miss 3 consecutive doses of your scheduled medicine.
            </p>
          </div>
        </section>

        <div className="pt-6 border-t border-neutral-100">
          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {saving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}
