import React, { useEffect, useState } from "react";
import { auth, db, collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc } from "../firebase";
import { Pill, Plus, Trash2, Edit2, Clock, X, Save, Info } from "lucide-react";
import { toast } from "sonner";
import { getMedicineInfo } from "../services/geminiService";
import { cn } from "../lib/utils";

interface Medicine {
  id: string;
  name: string;
  dosage: string;
  stock: number;
  stockAlertThreshold: number;
  times: string[];
  frequency: string;
}

export default function Medicines() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [medInfo, setMedInfo] = useState<{ [key: string]: string }>({});

  const [formData, setFormData] = useState({
    name: "",
    dosage: "",
    stock: 30,
    stockAlertThreshold: 5,
    times: ["08:00"],
    frequency: "daily",
  });

  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, "medicines"), where("uid", "==", user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const meds = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Medicine));
      setMedicines(meds);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      if (editingId) {
        await updateDoc(doc(db, "medicines", editingId), formData);
        toast.success("Medicine updated!");
      } else {
        await addDoc(collection(db, "medicines"), {
          ...formData,
          uid: user.uid,
          createdAt: new Date().toISOString(),
        });
        toast.success("Medicine added!");
      }
      setIsAdding(false);
      setEditingId(null);
      setFormData({ name: "", dosage: "", stock: 30, stockAlertThreshold: 5, times: ["08:00"], frequency: "daily" });
    } catch (error) {
      console.error("Error saving medicine:", error);
      toast.error("Failed to save medicine.");
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this medicine?")) return;
    try {
      await deleteDoc(doc(db, "medicines", id));
      toast.success("Medicine deleted.");
    } catch (error) {
      console.error("Error deleting medicine:", error);
      toast.error("Failed to delete medicine.");
    }
  };

  const handleEdit = (med: Medicine) => {
    setFormData({
      name: med.name,
      dosage: med.dosage,
      stock: med.stock,
      stockAlertThreshold: med.stockAlertThreshold,
      times: med.times,
      frequency: med.frequency,
    });
    setEditingId(med.id);
    setIsAdding(true);
  };

  const fetchInfo = async (name: string) => {
    if (medInfo[name]) return;
    toast.info(`Fetching info for ${name}...`);
    try {
      const info = await getMedicineInfo(name);
      setMedInfo(prev => ({ ...prev, [name]: info }));
    } catch (error) {
      toast.error("Failed to fetch medicine info.");
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">My Medicines</h1>
          <p className="text-neutral-500 mt-1 font-medium">Manage your prescriptions and schedules.</p>
        </div>
        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
          >
            <Plus size={20} />
            Add New
          </button>
        )}
      </header>

      {isAdding && (
        <section className="bg-white rounded-3xl p-8 border border-neutral-100 shadow-xl shadow-neutral-200/50 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-neutral-900">{editingId ? "Edit Medicine" : "Add New Medicine"}</h2>
            <button onClick={() => setIsAdding(false)} className="p-2 text-neutral-400 hover:text-neutral-600">
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Medicine Name</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                placeholder="e.g. Paracetamol"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Dosage</label>
              <input
                type="text"
                required
                value={formData.dosage}
                onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                placeholder="e.g. 500mg"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Current Stock (Doses)</label>
              <input
                type="number"
                required
                value={formData.stock}
                onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) })}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-neutral-700">Low Stock Alert Threshold</label>
              <input
                type="number"
                required
                value={formData.stockAlertThreshold}
                onChange={(e) => setFormData({ ...formData, stockAlertThreshold: parseInt(e.target.value) })}
                className="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-bold text-neutral-700">Reminder Times</label>
              <div className="flex flex-wrap gap-2">
                {formData.times.map((time, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-neutral-50 p-2 rounded-xl border border-neutral-200">
                    <input
                      type="time"
                      value={time}
                      onChange={(e) => {
                        const newTimes = [...formData.times];
                        newTimes[idx] = e.target.value;
                        setFormData({ ...formData, times: newTimes });
                      }}
                      className="bg-transparent outline-none font-medium text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, times: formData.times.filter((_, i) => i !== idx) })}
                      className="text-red-400 hover:text-red-600"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, times: [...formData.times, "12:00"] })}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border border-dashed border-neutral-300 text-neutral-500 hover:border-blue-400 hover:text-blue-600 transition-all text-sm font-medium"
                >
                  <Plus size={16} /> Add Time
                </button>
              </div>
            </div>

            <div className="md:col-span-2 pt-4">
              <button
                type="submit"
                className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center gap-2"
              >
                <Save size={20} />
                {editingId ? "Update Medicine" : "Save Medicine"}
              </button>
            </div>
          </form>
        </section>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {medicines.map((med) => (
          <div key={med.id} className="bg-white rounded-3xl p-6 border border-neutral-100 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                <Pill size={24} />
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => handleEdit(med)} className="p-2 text-neutral-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg">
                  <Edit2 size={18} />
                </button>
                <button onClick={() => handleDelete(med.id)} className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg">
                  <Trash2 size={18} />
                </button>
              </div>
            </div>

            <h3 className="text-xl font-bold text-neutral-900 mb-1">{med.name}</h3>
            <p className="text-neutral-500 font-medium text-sm mb-4">{med.dosage}</p>

            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-2 text-neutral-600 text-sm font-medium">
                <Clock size={16} className="text-neutral-400" />
                {med.times.join(", ")}
              </div>
              <div className="flex items-center gap-2 text-neutral-600 text-sm font-medium">
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  med.stock <= med.stockAlertThreshold ? "bg-red-500 animate-pulse" : "bg-green-500"
                )} />
                Stock: {med.stock} doses left
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-50 flex items-center justify-between">
              <button
                onClick={() => fetchInfo(med.name)}
                className="flex items-center gap-2 text-blue-600 font-bold text-xs hover:underline"
              >
                <Info size={14} />
                Medicine Info
              </button>
            </div>

            {medInfo[med.name] && (
              <div className="mt-4 p-4 bg-blue-50 rounded-2xl text-xs text-blue-800 leading-relaxed animate-in fade-in duration-300">
                <p className="whitespace-pre-wrap">{medInfo[med.name]}</p>
                <button onClick={() => setMedInfo(prev => ({ ...prev, [med.name]: "" }))} className="mt-2 text-blue-600 font-bold hover:underline">Close</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
