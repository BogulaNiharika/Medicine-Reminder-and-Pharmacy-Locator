import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, Pill, MapPin, MessageSquare, User, LogOut, Bell } from "lucide-react";
import { auth, signOut } from "../firebase";
import { cn } from "../lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const user = auth.currentUser;

  const navItems = [
    { name: "Home", path: "/", icon: Home },
    { name: "Medicines", path: "/medicines", icon: Pill },
    { name: "Pharmacies", path: "/pharmacies", icon: MapPin },
    { name: "AI Health Chat", path: "/chat", icon: MessageSquare },
    { name: "Profile", path: "/profile", icon: User },
  ];

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col md:flex-row">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-neutral-200 p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white">
            <Pill size={24} />
          </div>
          <h1 className="text-xl font-bold text-neutral-900 leading-tight">MedSmart</h1>
        </div>

        <nav className="flex-1 space-y-2">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                location.pathname === item.path
                  ? "bg-blue-50 text-blue-600 font-medium"
                  : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-900"
              )}
            >
              <item.icon size={20} />
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-neutral-100">
          <button
            onClick={() => signOut(auth)}
            className="flex items-center gap-3 px-4 py-3 w-full text-left text-neutral-500 hover:text-red-600 transition-colors"
          >
            <LogOut size={20} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile Navigation */}
      <header className="md:hidden bg-white border-b border-neutral-200 p-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <Pill className="text-blue-600" size={24} />
          <span className="font-bold text-lg">MedSmart</span>
        </div>
        <button className="p-2 text-neutral-500">
          <Bell size={20} />
        </button>
      </header>

      <main className="flex-1 p-4 md:p-8 pb-24 md:pb-8 max-w-6xl mx-auto w-full">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 px-2 py-3 flex justify-around items-center z-50">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={cn(
              "flex flex-col items-center gap-1 p-2 rounded-lg transition-colors",
              location.pathname === item.path ? "text-blue-600" : "text-neutral-400"
            )}
          >
            <item.icon size={20} />
            <span className="text-[10px] font-medium">{item.name}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
